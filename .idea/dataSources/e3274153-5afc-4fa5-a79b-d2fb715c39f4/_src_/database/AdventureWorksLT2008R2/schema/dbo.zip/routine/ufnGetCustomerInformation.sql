CREATE FUNCTION [dbo].[ufnGetCustomerInformation](@CustomerID int)
RETURNS TABLE 
AS 
RETURN (
SELECT 
CustomerID, 
FirstName, 
LastName
FROM [SalesLT].[Customer] 
WHERE [CustomerID] = @CustomerID
);
GO
