CREATE PROCEDURE [dbo].[uspPrintError] 
AS
BEGIN
SET NOCOUNT ON;
PRINT 'Error ' + CONVERT(varchar(50), ERROR_NUMBER()) +
', Severity ' + CONVERT(varchar(5), ERROR_SEVERITY()) +
', State ' + CONVERT(varchar(5), ERROR_STATE()) + 
', Procedure ' + ISNULL(ERROR_PROCEDURE(), '-') + 
', Line ' + CONVERT(varchar(5), ERROR_LINE());
PRINT ERROR_MESSAGE();
END;
GO
